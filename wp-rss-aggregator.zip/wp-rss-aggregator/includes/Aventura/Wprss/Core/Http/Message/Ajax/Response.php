<?php

namespace Aventura\Wprss\Core\Http\Message\Ajax;

/**
 * A concrete response, for easy use.
 *
 * @since 4.9
 */
class Response extends AbstractResponse
{
}
