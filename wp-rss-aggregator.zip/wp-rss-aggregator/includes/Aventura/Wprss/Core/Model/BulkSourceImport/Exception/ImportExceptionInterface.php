<?php

namespace Aventura\Wprss\Core\Model\BulkSourceImport\Exception;

/**
 * Something that can represent an error that occurs during import of feed sources.
 *
 * @since 4.11
 */
interface ImportExceptionInterface
{
}
