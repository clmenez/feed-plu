<?php

namespace Aventura\Wprss\Core\Model\Set;

/**
 * Simple concrete set implementation.
 *
 * @since 4.10
 */
class Set extends AbstractGenericSet
{
}
