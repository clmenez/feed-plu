<?php

namespace Aventura\Wprss\Core\Model;

use Psr\Log\LoggerInterface as PsrLoggerInterface;

/**
 * Alias for PSR-3 logger interface.
 *
 * @since 4.8.1
 */
interface LoggerInterface extends PsrLoggerInterface
{
}
