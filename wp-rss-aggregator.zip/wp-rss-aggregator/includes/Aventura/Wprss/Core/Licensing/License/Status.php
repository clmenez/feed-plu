<?php

namespace Aventura\Wprss\Core\Licensing\License;

use RebelCode\Wpra\Core\Licensing\LicenseStatus;

/**
 * Enum-style abstract class for license statuses.
 */
abstract class Status extends LicenseStatus {
}
