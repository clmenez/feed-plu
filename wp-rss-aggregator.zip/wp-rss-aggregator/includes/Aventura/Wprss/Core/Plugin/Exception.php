<?php

namespace Aventura\Wprss\Core\Plugin;

use Aventura\Wprss\Core;

/**
 * The base class for all WP plugins.
 *
 * @since 4.8.1
 */
class Exception extends Core\Exception
{
    //put your code here
}