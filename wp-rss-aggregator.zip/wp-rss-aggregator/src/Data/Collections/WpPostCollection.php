<?php

namespace RebelCode\Wpra\Core\Data\Collections;

// Autoload the new class
class_exists('RebelCode\Wpra\Core\Entities\Collections\WpEntityCollection');
