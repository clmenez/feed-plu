<?php

namespace RebelCode\Wpra\Core;

/**
 * The WP RSS Aggregator plugin module.
 *
 * @since 4.13
 */
class Plugin extends ModularModule
{
}
